
BOOL SetRootDir(char * dir);
BOOL MySetDir(char * dir);
char * MyGetDir(void);
char * TranslatePath(const char * FilePath);
